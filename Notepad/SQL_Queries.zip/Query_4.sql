-- Monthly Sales trends
SELECT
    YEAR(Date) AS Year,
    MONTH(Date) AS Month,
    SUM(Final_Amount) AS Total_Sales
FROM
    Retail_Sales
GROUP BY
    YEAR(Date),
    MONTH(Date)
ORDER BY
	Total_sales desc

--impact Of Discount on revenuw
CREATE VIEW Analysis.impact_of_discount AS
SELECT
    CASE
        WHEN Discount_Applied > 0 THEN 'Discounted Sales'
        ELSE 'Non-Discounted Sales'
    END AS Sale_Type,
    COUNT(Transaction_ID) AS Number_of_Transactions,
    SUM(Total_Amount) AS Gross_Revenue,
    SUM(Final_Amount) AS Net_Revenue,
    SUM(Total_Amount) - SUM(Final_Amount) AS Total_Discount_Amount,
    AVG(Discount_Applied) AS Average_Discount_Percentage
FROM
    Retail_Sales
GROUP BY
    CASE
        WHEN Discount_Applied > 0 THEN 'Discounted Sales'
        ELSE 'Non-Discounted Sales'
    END;
