-- Best-performing sales representatives.
CREATE VIEW Analysis.Best_performing_Rep AS
SELECT
    Sales_Representative,
    COUNT(Transaction_ID) AS Number_of_Transactions,
    SUM(Final_Amount) AS Total_Sales,
    AVG(Final_Amount) AS Average_Sale_Amount
FROM
    Retail_Sales
GROUP BY
    Sales_Representative
ORDER BY
    Total_Sales DESC;
