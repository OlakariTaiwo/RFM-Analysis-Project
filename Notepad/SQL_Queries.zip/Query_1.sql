-- To evaluate sales performance by store location
CREATE VIEW Analysis.Performance_by_location AS
SELECT
    Store_Location,
    COUNT(Transaction_ID) AS Number_of_Transactions,
    SUM(Final_Amount) AS Total_Sales,
    AVG(Final_Amount) AS Average_Sale_Amount
FROM
    Retail_Sales
GROUP BY
    Store_Location
ORDER BY
    Total_Sales DESC;
