--lets PErform Some Time Base Series Analysis
	--- Sales by day of the week.
	CREATE VIEW Analysis.Sales_by_weekdays AS
SELECT
    DATENAME(weekday, Date) AS DayOfWeek,
    COUNT(Transaction_ID) AS Number_of_Transactions,
    SUM(Final_Amount) AS Total_Sales,
    AVG(Final_Amount) AS Average_Sale_Amount
FROM
    Retail_Sales
GROUP BY
    DATENAME(weekday, Date),
    DATEPART(weekday, Date)
ORDER BY
    DATEPART(weekday, Date);
